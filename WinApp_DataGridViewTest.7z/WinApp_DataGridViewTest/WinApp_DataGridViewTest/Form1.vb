﻿Public Class Form1

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv1.CellContentClick

    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' Visualスタイルを使用しない
        dgv1.EnableHeadersVisualStyles = False

        ' 列ヘッダの背景色の変更
        dgv1.ColumnHeadersDefaultCellStyle.BackColor = Color.Red
        ' 行ヘッダの背景色の変更
        dgv1.RowHeadersDefaultCellStyle.BackColor = Color.Green
    End Sub
End Class
