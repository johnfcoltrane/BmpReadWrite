﻿Imports System
Imports Microsoft.VisualBasic.FileIO

Class CSVParser
    Shared Sub Main(ByVal args() As String)

        If (UBound(args) < 0) Then
            Console.WriteLine("no param")
            Return
        End If
        Dim fname As String = args(0)
        Using parser As New TextFieldParser(fname, _
         System.Text.Encoding.GetEncoding("Shift_JIS"))

            parser.TextFieldType = FieldType.Delimited
            parser.SetDelimiters(",") ' 区切り文字はコンマ

            ' parser.HasFieldsEnclosedInQuotes = False
            ' parser.TrimWhiteSpace = False

            While Not parser.EndOfData
                Dim row As String() = parser.ReadFields() ' 1行読み込み

                For Each field As String In row
                    field = field.Replace(vbCrLf, "n") ' 改行をnで表示
                    field = field.Replace(" ", "_") ' 空白を_で表示
                    Console.Write(field + vbTab) ' TAB区切りで出力
                Next
                Console.WriteLine()
            End While
        End Using
    End Sub
End Class

' コンパイル方法：vbc csvparser.vb