﻿Public Class Form1

    Private Sub RoundButton1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RoundButton1.MouseDown
        Console.WriteLine("** MouseDown !!!")
    End Sub

    Private Sub RoundButton1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles RoundButton1.MouseEnter
        Console.WriteLine("** MouseEnter !!!")
        Me.RoundButton1.BackColor = Color.Red
        Me.RoundButton1.FlatAppearance.BorderSize = 0
        Me.RoundButton1.FlatStyle = FlatStyle.Flat
    End Sub

    Private Sub RoundButton1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles RoundButton1.MouseLeave
        Console.WriteLine("** MouseLeave !!!")
        Me.RoundButton1.BackColor = Color.Lime
    End Sub

    Private Sub RoundButton1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RoundButton1.MouseUp
        Console.WriteLine("** MouseUp !!!")
    End Sub

    Private Sub RoundButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RoundButton1.Click

    End Sub
End Class
