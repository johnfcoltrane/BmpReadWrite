﻿Imports System.Windows.Forms
Imports System.Drawing.Drawing2D

Public Class EllipseButton
    Inherits Button

    Protected Overrides Sub OnPaint(ByVal pevent As PaintEventArgs)
        Dim gp As GraphicsPath = New GraphicsPath
        gp.StartFigure()
        gp.AddEllipse(0, 0, ClientSize.Width, ClientSize.Height)
        gp.CloseFigure()
        Me.Region = New System.Drawing.Region(gp)
        MyBase.OnPaint(pevent)
    End Sub
End Class
