﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SideRoundButton1 = New CircleButton.SideRoundButton
        Me.RoundButton1 = New CircleButton.RoundButton
        Me.EllipseButton1 = New CircleButton.EllipseButton
        Me.SuspendLayout()
        '
        'SideRoundButton1
        '
        Me.SideRoundButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.SideRoundButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SideRoundButton1.FlatAppearance.BorderSize = 0
        Me.SideRoundButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.SideRoundButton1.Location = New System.Drawing.Point(110, 15)
        Me.SideRoundButton1.Name = "SideRoundButton1"
        Me.SideRoundButton1.Size = New System.Drawing.Size(113, 53)
        Me.SideRoundButton1.TabIndex = 3
        Me.SideRoundButton1.Text = "SideRoundButton1"
        Me.SideRoundButton1.UseVisualStyleBackColor = False
        '
        'RoundButton1
        '
        Me.RoundButton1.BackColor = System.Drawing.Color.Lime
        Me.RoundButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RoundButton1.FlatAppearance.BorderSize = 0
        Me.RoundButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime
        Me.RoundButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime
        Me.RoundButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RoundButton1.Location = New System.Drawing.Point(23, 97)
        Me.RoundButton1.Name = "RoundButton1"
        Me.RoundButton1.Round = 50.0!
        Me.RoundButton1.Size = New System.Drawing.Size(245, 104)
        Me.RoundButton1.TabIndex = 1
        Me.RoundButton1.Text = "RoundButton1"
        Me.RoundButton1.UseVisualStyleBackColor = False
        '
        'EllipseButton1
        '
        Me.EllipseButton1.BackColor = System.Drawing.Color.Cyan
        Me.EllipseButton1.FlatAppearance.BorderSize = 0
        Me.EllipseButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.EllipseButton1.Location = New System.Drawing.Point(12, 12)
        Me.EllipseButton1.Name = "EllipseButton1"
        Me.EllipseButton1.Size = New System.Drawing.Size(67, 31)
        Me.EllipseButton1.TabIndex = 0
        Me.EllipseButton1.Text = "EllipseButton1"
        Me.EllipseButton1.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(291, 333)
        Me.Controls.Add(Me.SideRoundButton1)
        Me.Controls.Add(Me.RoundButton1)
        Me.Controls.Add(Me.EllipseButton1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents EllipseButton1 As CircleButton.EllipseButton
    Friend WithEvents RoundButton1 As CircleButton.RoundButton
    Friend WithEvents SideRoundButton1 As CircleButton.SideRoundButton

End Class
