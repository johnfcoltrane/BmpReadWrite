﻿Imports System.Windows.Forms
Imports System.Drawing.Drawing2D

Public Class SideRoundButton
    Inherits Button

    Protected Overrides Sub OnPaint(ByVal pevent As PaintEventArgs)
        Dim gp As GraphicsPath = New GraphicsPath
        Dim x As Single = 0.0F
        Dim y As Single = 0.0F
        Dim w As Single = ClientSize.Width
        Dim h As Single = ClientSize.Height
        gp.StartFigure()
        gp.AddArc(x, y, h, h, 90.0F, 180.0F)
        gp.AddArc(w - h, y, h, h, 270.0F, 180.0F)
        gp.CloseFigure()
        Me.Region = New System.Drawing.Region(gp)
        MyBase.OnPaint(pevent)
    End Sub
End Class