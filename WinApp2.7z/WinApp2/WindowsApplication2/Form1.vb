﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim s As String
        s = fnc1()
        If s <> "" Then
            Me.pbx1.ImageLocation = s
        End If
    End Sub
End Class
