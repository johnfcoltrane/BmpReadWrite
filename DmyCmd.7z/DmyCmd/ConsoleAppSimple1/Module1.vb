﻿Module Module1

    Sub Main(ByVal argv() As String)
        Dim pause As Boolean = False
        Dim ix As Integer = 0
        For Each i As String In argv
            Console.WriteLine("prm[" + ix.ToString() + "]='" + i + "'")
            If i = "-p" Then
                pause = True
            End If
            ix += 1
        Next
        If pause Then
            Console.Write("pause:")
            Console.ReadLine()
        End If
    End Sub

End Module
